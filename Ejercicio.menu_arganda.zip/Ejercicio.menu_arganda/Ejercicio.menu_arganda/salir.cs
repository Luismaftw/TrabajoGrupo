﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ejercicio.menu_arganda
{
    class salir
    {
        static void Main(string[] args)
        {
        salir:

            break;

        }
    }
}
